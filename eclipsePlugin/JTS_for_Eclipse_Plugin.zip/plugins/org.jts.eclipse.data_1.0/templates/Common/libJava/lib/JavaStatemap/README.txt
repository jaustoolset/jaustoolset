


                              SMC -
                     The State Machine Compiler


+ Building & Installing statemap.jar
------------------------------------

1. If you have built statemap.jar previously and want to perform
   a complete build, then do

   $ make clean

2. Build statemap.jar:

   $ make statemap.jar

3. To install statemap.jar in the Smc distribution directory
   tree, do:

   $ make install

NOTE: You must build statemap.jar before you can build Smc.jar.

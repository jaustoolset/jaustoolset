


                              SMC -
                     The State Machine Compiler


+ Building & Installing statemap.dll
------------------------------------

NOTE: This code only should be used to generate statemap.dll.
This dll should be used for both CSharp and VB.net applications.

1. If you have built statemap.dll previously and want to perform
   a complete build, then do

   $ make clean

2. Build statemap.dll:

   (Must use Microsoft DevStudio v. 7.0 or later. Build both
    Debug and Release configurations.)

3. To install statemap.dll in the Smc distribution directory
   tree, do:

   $ make install

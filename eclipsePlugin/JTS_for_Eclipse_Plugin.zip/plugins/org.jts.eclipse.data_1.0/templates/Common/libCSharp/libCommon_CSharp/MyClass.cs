
using System;

namespace libCommon_CSharp
{


	public class MyClass
	{

		public MyClass ()
		{
		}
	}
}


using System;
/*
 * Developed by
 * ProgenySystems Corporation
 * 9500 Innovation Drive
 * Manassas, VA 20110-4716
 * For the
 * JAUS Tool Set
 *
 * Change History:
 * Date | Author | Description
 * ---------------------------
 * 11/5/10 | Gina Nearing | initial
 *
 *
******************************/
namespace libCommon_CSharp
{


	public class Main
	{

		public Main ()
		{
			
			//SimpleThread t = new SimpleThread();
			//t.start();
			
		}
	}
}
